#include <stdio.h>
#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <iostream>
#include <std_msgs/String.h>
#include <string>

std::string data;

void counterCallback(const std_msgs::String &msg)
{
    data=msg.data;
   
}

int main(int argc, char **argv)
{
    
    ros::init(argc, argv, "add_markers");
    ros::NodeHandle n;
    ros::Rate r(1);
    ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker",1);

    
    ros::Subscriber sub=n.subscribe("pick_and_drop",3,counterCallback);
    bool pick=false;

    //an integer to keep track of what shape is going to be published
    uint32_t shape = visualization_msgs::Marker::CUBE;

    while (ros::ok())
	{
    		visualization_msgs::Marker marker;
    		// Set the frame ID and timestamp.  See the TF tutorials for information on these.
    		marker.header.frame_id = "map";
    		marker.header.stamp = ros::Time::now();

		marker.ns="add_markers";
		marker.id=0;

		marker.type=shape;

		marker.action=visualization_msgs::Marker::ADD;
		

		// Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
		marker.pose.position.x = -3;
		marker.pose.position.y = 3;
		marker.pose.position.z = 0;
		marker.pose.orientation.x = 0.0;
		marker.pose.orientation.y = 0.0;
		marker.pose.orientation.z = 0.0;
		marker.pose.orientation.w = 1.0;

		// Set the scale of the marker -- 1x1x1 here means 1m on a side
		marker.scale.x = 0.5;
		marker.scale.y = 0.5;
		marker.scale.z = 0.5;

		// Set the color -- be sure to set alpha to something non-zero!
		marker.color.r = 0.0f;
		marker.color.g = 0.0f;
		marker.color.b = 1.0f;
		marker.color.a = 1.0;
		marker.lifetime = ros::Duration();

        	if(data!="picking" && pick==false)
        	{
		ROS_INFO("Pick up marker");
		std::cout << "Waiting for marker to be picked up" << std::endl; 
		


		// Publish the marker
		while (marker_pub.getNumSubscribers() < 1)
		{
  			if (!ros::ok())
  			{
    				return 0;
  			}
  			ROS_WARN_ONCE("Please create a subscriber to the marker");
  			sleep(1);
		}
		marker_pub.publish(marker);
		}
       		if(data=="picking" && pick==false)
		{
		pick=true;
		ROS_INFO("Hide Marker");
		std::cout << "Picking the marker at pickup location" <<std::endl;
		marker.action=visualization_msgs::Marker::DELETE;
		marker.lifetime = ros::Duration();
		marker_pub.publish(marker);
		}

		marker.type=shape;
		marker.action=visualization_msgs::Marker::ADD;
		
        	marker.pose.position.x = -1;
		marker.pose.position.y = -2;
		marker.pose.position.z = 0;
		marker.pose.orientation.x = 0.0;
		marker.pose.orientation.y = 0.0;
		marker.pose.orientation.z = 0.0;
		marker.pose.orientation.w = 1.0;

		marker.scale.x = 0.5;
		marker.scale.y = 0.5;
		marker.scale.z = 0.5;
		marker.lifetime = ros::Duration();

		if(data=="dropping" && pick==true)
		{
		ROS_INFO("Drop off");
		std::cout << "Dropping the marker at dropoff location" << std::endl;
		marker_pub.publish(marker);
		}
	ros::spinOnce();
	r.sleep();
        }
		

        
        
    }

   

